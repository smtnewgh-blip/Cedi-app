import OpenAI from "openai";

let client: OpenAI | null = null;

function getClient(): OpenAI {
  if (!process.env.OPENAI_API_KEY) {
    throw new Error(
      "OPENAI_API_KEY is not set. Add it to your environment variables (.env.local for development, or your deployment platform's secrets) to enable AI chat responses."
    );
  }
  if (!client) {
    client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  }
  return client;
}

/**
 * Generates a single AI text response for the given user message.
 * Used by app/api/ai/chat/route.ts.
 */
export async function generateAIResponse(message: string): Promise<string> {
  const openai = getClient();

  const completion = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [
      {
        role: "system",
        content:
          "You are the CediApp assistant, helping users understand Ghana's digital cedi ecosystem, CediCoin, and related civic and financial services. Be concise, accurate, and avoid giving financial or legal advice as fact.",
      },
      { role: "user", content: message },
    ],
    max_tokens: 500,
  });

  return completion.choices[0]?.message?.content ?? "";
}
